# DOOMFLY publication copy

This archive preserves the identified Doom experiments and recorded results.
It is a publication copy, not a byte-identical original run archive. Unrelated
simulation helpers and external paper/workbook downloads are excluded. Required
MaleCNS import/sign helpers are now under doom/; corresponding Python imports
are updated. Full project and third-party license notices are included.

Original experimental source hashes in the records identify the sources used
for those historical runs. Packaging and namespace changes do not establish a
new scientific result. The separate member manifest hashes these published
bytes, excluding the manifest itself. Current behavior/protocol is documented
in the repository; historical notes describe the experiment at the time it ran.
