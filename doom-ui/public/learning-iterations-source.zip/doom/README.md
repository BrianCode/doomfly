# Fly Brain / Doom

This is a live whole-connectome **neural BCI experiment**, not a validated fly
emulation or a trained Doom player. The fixed visual-neuron BCI turns, moves and
fires in ViZDoom. A comprehensive review found and corrected a refractory-event
error; old kill counts are legacy results, not validation of the current model.
See [the neuroscience review](../docs/doom-neuroscience-review.md) and
`outputs/doom/audit/experiments.json` for matched controls and scientific limits.
These checks do not establish skill, learning, or natural motor semantics. The biological-role
comparison (DNa02, DNp09, MDN, MN9) remains silent in the initial visual test.

## What runs

## Reproduce

Use the existing isolated Python 3.11 environment and full imported graph.

```sh
.venv-neural/bin/python -m pip install -r doom/requirements.txt
.venv-neural/bin/python -m doom.prepare
.venv-neural/bin/python -m doom.audit_data
.venv-neural/bin/python -m doom.build_kernel
.venv-neural/bin/python -m pytest tests/test_doom.py tests/test_doom_reference.py tests/test_connectome.py -q
.venv-neural/bin/python -m doom.audit_experiments
.venv-neural/bin/python -m doom.server
```

The build helper selects the platform suffix, replaces the library atomically,
and writes source/binary hashes. The runtime rejects a stale or modified binary.
On Linux the helper builds `libneural.so`.
Do not run many full-graph processes concurrently on a small machine.
`--condition` permits named ablations; they are labeled in every frame. The
intact graph is never silently pruned. `--reward sugar` enables stimulus delivery.
The local service binds **only 127.0.0.1:8766**, with GET /state and GET /health.
There is no remote control, filesystem serving, secret exposure or write API.
A broadcaster audit log records source-frame, input and spike hashes plus all
requested/applied actions for every game tic. Audit storage rotates at 20 MB with
four backups (100 MB total); run IDs distinguish restarts.

## Evidence and limits

- Graph and model framework: https://www.nature.com/articles/s41586-024-07763-9
- Male visual columns: https://www.nature.com/articles/s41586-025-08746-0
- Graded visual modeling: https://www.nature.com/articles/s41586-024-07939-3
- Histamine/receptor physiology: https://www.nature.com/articles/s41586-023-06681-6
- DNa02 steering: https://elifesciences.org/articles/102230
- Descending control: https://www.nature.com/articles/s41586-024-07523-9
- MN9 mouthpart control: https://elifesciences.org/articles/19892
- Visual reinforcement: https://elifesciences.org/articles/02395

The efficient kernel skips only subthreshold evolution that cannot produce a
spike without an input event, then analytically materializes it at the next event.
No weak edges or inactive neurons are removed from the graph. Toy-network tests
compare counts/voltages to a dense reference with changing inputs and inhibition.
Full-graph interventions test retinal causality and total disconnection, including
matched BCI readouts. A 210-tic live closed-loop test recorded actual game actions. These
are numerical/causal implementation checks, not biological validation.
