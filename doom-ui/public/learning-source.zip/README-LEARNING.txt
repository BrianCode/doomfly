DOOMFLY learning experiment source and recorded pilot

Start with doom_learning/README.md and docs/doom-learning-review.md.
The candidate currently fails scientific validation. No learning is claimed.
The public broadcast remains a separate fixed-connection baseline.

Original pilot sources are frozen under outputs/doom-learning/survival-pilot/source-snapshot.
The top-level experiment code contains later methodological fixes documented in the review.
Do not relabel old results as outputs of the later code.

The full graph, raw release files, annotations, native binaries, Python environment,
and large brain checkpoints are NOT bundled. Use the official MaleCNS release and
the preparation/data-audit scripts described in doom/README.md. No smaller graph
is a scientifically interchangeable substitute. Dataset provenance is included.
